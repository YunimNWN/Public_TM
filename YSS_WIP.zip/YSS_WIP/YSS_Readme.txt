
##########
# Title: Yunim's Shifter System
# Author: Yunim
# Version: v0.1
# Date: xxxx/xx/xx
##########

0 - Contents

1) Overview
2) Includes
3) Shifter_PolymorphTarget()
4) Polymorph Scripts
5) Module Event Scripts
6) Effects
7) Single Player Overrides

##########

1 - Overview

This shifter system improves several aspects of polymorph for both PCs and NPCs in NWN:EE.
The system allows for modifying item merging, item property stacking, and true seeing replacement on polymorph forms.
It also contains bug fixes related to shifter death along with several other general polymorph bug fixes.
*** UPDATE BEFORE RELEASE *** NWN:EE v1.81.8193.16 is required for the shifter system to work properly.

##########

2 - Includes

There are two main include files for the shifter system: "y__shifter" and "y__shifterswitch".
All constants contained in "y__shifter" are prefixed with "SHIFTER_".
All functions contained in "y__shifter" are prefixed with "Shifter_".
All constants contained in "y__shifterswitch" are prefixed with "SHIFTERSWITCH_".

"y__shifter" is an include file containing all functions used by the shifter system.
In particular this file contains the function "Shifter_PolymorphTarget()", which is the central focus of the shifter system.
None of the constants or functions in y__shifter should be modified unless you understand how the system works.

"y__shifterswitch" is an include file containing constants that customise the shifter system.
Most constants in y__shifterswitch have a default value which corresponds to their value in vanilla NWN.
The values in y__shifterswitch can be changed without issue, provided that all requirements for the switches are met.
Module builders may choose to replace the constants in y__shifterswitch with local variables to allow for ingame shifter system customisation.
Be aware that this may have unintended consequences, especially with regards to modified module event scripts.

eg. Setting SHIFTERSWITCH_MODIFIED_ONPLAYERUNEQUIPITEM = TRUE requires adding the function Shifter_OnPlayerUnEquipItem() to the OnPlayerUnEquipItem module event script.
If the value of this switch is TRUE but the OnPlayerUnEquipItem event is unmodified then the shifter system will fail to work properly.
If the OnPlayerUnEquipItem event has been modified appropriately then this switch can be set to TRUE or FALSE without any issues.

There are three important classes of switches, found at the top of y__shifterswitch, with the following prefixes:
"SHIFTERSWITCH_EFFECT_TAG_" : Sets effect tags used by the shifter system. These should be unique effect tags that are not used anywhere else in the module. DO NOT set these to "", bad things will happen.
"SHIFTERSWITCH_MODIFIED_" : Determines whether subsystems that require specific modified scripts are safe to use. DO NOT set these to TRUE if you have not modified the specified scripts appropriately, bad things will happen.
"SHIFTERSWITCH_VARIABLE_NAME_" : Sets local variable names used by the shifter system. These should be unique variable names that are not used anywhere else in the module. DO NOT set these to "", bad things will happen.

##########

3 - Shifter_PolymorphTarget()

Shifter_PolymorphTarget() is the main focus of the shifter system.
Most shifter system settings only apply to polymorph effects created by Shifter_PolymorphTarget().
It can be used in any script that polymorphs a creature, including custom polymorph scripts, and can also handle custom polymorph forms (created by editing polymorph.2da).
The following default polymorph forms should not be used with Shifter_PolymorphTarget(): 44 (POLYMORPH_TYPE_JNAH_GIANT_MALE), 45 (POLYMORPH_TYPE_JNAH_GIANT_FEMALE), 46, 47, 48, 49, 50, 57 (POLYMORPH_TYPE_GOLEM_AUTOMATON).
y__shifterswitch contains more information regarding the issues with these forms, as well as an overview of other potential bugs with the shifter system.

For ease of customisation, Shifter_PolymorphTarget() is built up using other functions defined in y__shifter.
This will allow advanced users to create modified polymorph functions that only use some of the shifter settings defined in y__shifterswitch.
It is possible to rewrite Shifter_PolymorphTarget() with extra parameters so that the shifter settings defined in y__shifterswitch are default arguments rather than inbuilt constants.
However, this increased customisation would take a lot of effort while also complicating certain aspects of the system.
Adding extra constants in y__shifterswitch and creating modified copies of functions in y__shifter that use the new constants should offer enough flexibility for most environments.

##########

4 - Polymorph Scripts

There are six modified polymorph scripts that make use of the shifter system: "nw_s0_polyself", "nw_s0_shapechg", "nw_s0_tenstrans", "nw_s2_elemshape", "nw_s2_wildshape", and "x2_s2_gwildshp".
These scripts are for Polymorph Self, Shapechange, Tenser's Transformation, Elemental Shape, Wild Shape, and Greater Wildshape respectively.

If you only want the shifter system to affect some of these scripts (eg. only Elemental Shape, Wild Shape, and Greater Wildshape), then copy those modified scripts into your module and ignore the others.

If all constants in y__shifterswitch are set to their default values then there are only two changes from vanilla NWN when using these modified scripts.
All other aspects of these six scripts are identical to the default scripts that do not use Shifter_PolymorphTarget().
1) A 0.5 second delay has been removed from Shapechange. This is done to prevent separating the polymorph effect applied by Shifter_PolymorphTarget() from the spell information of Shapechange.
2) The temporary HP applied by Tenser's Transformation has an effect tag of SHIFTERSWITCH_EFFECT_TAG_TEMP_HP (defined in y__shifterswitch) instead of "".

##########

5 - Module Event Scripts

The shifter system uses up to four module event scripts, depending on the active subsystems.
These events are: OnPlayerDeath, OnPlayerEquipItem, OnPlayerRest, and OnPlayerUnEquipItem.

OnPlayerDeath and OnPlayerRest are both straightforward, they only apply if a subsystem triggers on a player's death or when a player rests respectively.

While Shifter_PolymorphTarget() can be considered an "OnShift" event in most cases, there is no "OnDeshift" event in the base game.
For PCs OnDeshift can be simulated with the OnPlayerUnEquipItem module event, provided that the polymorph form has items while polymorphed.
In particular, the shifter system assumes that all polymorph forms have a valid creature skin.
If this is not the case then multiple subsystems will fail to work properly.
Unfortunately there is no corresponding event for NPCs, so anything that should apply to the OnDeshift event is only relevant for PCs.

There are some cases where Shifter_PolymorphTarget() differs from an OnShift event, in these cases the OnPlayerEquipItem module event is used to simulate OnShift.
Again, the shifter system assumes that all polymorph forms have a valid creature skin.

##########

6 - Effects

The shifter system applies two classes of effects, general effects and temporary HP effects.
The effect tags of these effects are SHIFTERSWITCH_EFFECT_TAG_GENERAL and SHIFTERSWITCH_EFFECT_TAG_TEMP_HP respectively, which are both defined in y__shifterswitch.

General effects are only applied to players if OnPlayerUnEquipItem has been modified, since they are removed when the player deshifts.
They are never applied to NPCs since there is no guarantee that they will be removed when the polymorph effect is removed.
All general effects are applied as permanent extraordinary effects and so they can not be dispelled in vanilla NWN.
If they are not removed in the OnPlayerUnEquipItem event then they will be removed if: the player dies, the player rests, all effects are removed from the player, or Shifter_EffectRemoveByTag() is used on the player.

Temporary HP effects are applied to both NPCs and PCs that use Shifter_PolymorphTarget().
Temporary HP subtype and duration matches the subtype and duration of the polymorph effect applied by Shifter_PolymorphTarget().
They are only applied if the base polymorph form does not have any temporary HP (defined by HPBONUS in polymorph.2da).
There are switches to prevent temporary HP stacking when shifting (for both NPCs and PCs) and to remove temporary HP when deshifting (PCs only).

##########

7 - Single Player Overrides

This section is for players rather than module builders.

If you experience any unusual bugs with polymorph while using this method, delete the relevant files from your override folder.
Be aware that this method will probably result in bugs when playing in multiplayer, since override files can cause multiple problems that server owners can't account for.
If you use this method and experience any bugs while polymorphed in multiplayer, delete the files and try again before messaging the server owners.

The shifter system can be used to modify polymorph in single player by using the override folder.
This will work for any of the six polymorph scripts the attached module contains: Polymorph Self, Shapechange, Tenser's Transformation, Elemental Shape, Wild Shape, and Greater Wildshape.
Be aware that some modules will override the override folder, so this method won't work for all single player modules.
ALL "SHIFTERSWITCH_MODIFIED_" switches should be set to FALSE if you decide to do this, since the single player modules will not have the necessary script modifications.

First, open the module "Yunim's Shifter System.mod" in the toolset.
In the left panel, click on the "Scripts" tab and open the script "y__shifterswitch".
Make sure that the values of the "SHIFTERSWITCH_MODIFIED_" constants are all set to FALSE.
Choose your desired values for the constants, keeping in mind the requirements for enabling the constants.
None of the constants that require any "SHIFTERSWITCH_MODIFIED_" constants to be TRUE will work when using this method.
Save "y__shifterswitch" and close the script editor.
Go to the top toolbar and select the "Build" tab and then click "Build Module".
Make sure that the "Compile > Scripts" setting is ticked, which might require opening the "Advanced Controls" section.
Click "Build" and then "Done", there should be a message saying "No errors found".
Save the module but DON'T close the toolset.
Go to your modules folder, which should contain a folder named "temp0".
Inside this folder there will be various files and file types, the important ones here are ".ncs" files.
To modify the specified polymorph script, copy the .ncs file of that script to your override folder.
After you have finished copying the chosen .ncs files, you can close the toolset.
The shifter settings you chose should now work in most single player modules.

Polymorph scripts and their .ncs file names:
Polymorph Self: "nw_s0_polyself.ncs"
Shapechange: "nw_s0_shapechg.ncs"
Tenser's Transformation: "nw_s0_tenstrans.ncs"
Elemental Shape: "nw_s2_elemshape.ncs"
Wild Shape: "nw_s2_wildshape.ncs"
Greater Wildshape: "x2_s2_gwildshp.ncs"

For example, if you only want to modify Elemental Shape, Wild Shape, and Greater Wildshape then you should only copy "nw_s2_elemshape.ncs", "nw_s2_wildshape.ncs", and "x2_s2_gwildshp.ncs" into your override folder.

##########
