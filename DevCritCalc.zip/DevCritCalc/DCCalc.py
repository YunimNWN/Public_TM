##########
import pathlib
import sys
sys.path.append(str(pathlib.Path(__file__).parent.absolute()))
##########
#from __Stats_1_A import *
#from __Stats_1_B import *
#from __Stats_2_A import *
#from __Stats_2_B import *
#from __Stats_2_C import *
#from __Stats_3_A import *
#from __Stats_3_B import *
from __Stats_4_A import *
#from __Stats_4_B import *
##########
TargetHasBonusCON = False
if TargetHasBonusCON:
    Target_Level = 35
    TemplateTarget_HP += (Target_Level * 6)
##########
# AttackerA
AttackerA_Label = "AttackerA"
AttackerA_HasBlindFight = False
AttackerA_IsRangedAttack = False
AttackerA_DevastatingCriticalDC = 45
AttackerA_SneakDice = 0
AttackerA_MHAB = [59, 54, 49, 44, 59]
AttackerA_OHAB = []
AttackerA_MHThreatRange = 15
AttackerA_OHThreatRange = 20
AttackerA_MHDI = [0, 0]
AttackerA_OHDI = []
AttackerA_MHOnHitDI = []
AttackerA_OHOnHitDI = []
AttackerA_MHDR = [0, 0]
AttackerA_OHDR = []
AttackerA_MHOnHitDR = []
AttackerA_OHOnHitDR = []
AttackerA_MHOnHitProbability = []
AttackerA_OHOnHitProbability = []
def AttackerA_MHNormalDamageRoll(): return [nDx(1, 8) + 20 + 10, nDx(2, 6)]
def AttackerA_MHCritalDamageRoll(): return [nDx(2, 8) + 40 + 20 + nDx(2, 6), nDx(4, 6)]
def AttackerA_OHNormalDamageRoll(): return []
def AttackerA_OHCritalDamageRoll(): return []
def AttackerA_MHOnHitDamageRoll(): return []
def AttackerA_OHOnHitDamageRoll(): return []
def AttackerA_ARTD():
    GetARTD(
        AttackerA_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        AttackerA_HasBlindFight, AttackerA_IsRangedAttack, AttackerA_DevastatingCriticalDC, AttackerA_SneakDice,
        AttackerA_MHAB, AttackerA_OHAB, AttackerA_MHThreatRange, AttackerA_OHThreatRange,
        AttackerA_MHDI, AttackerA_MHDR, AttackerA_MHNormalDamageRoll, AttackerA_MHCritalDamageRoll,
        AttackerA_OHDI, AttackerA_OHDR, AttackerA_OHNormalDamageRoll, AttackerA_OHCritalDamageRoll,
        AttackerA_MHOnHitDI, AttackerA_MHOnHitDR, AttackerA_MHOnHitProbability, AttackerA_MHOnHitDamageRoll,
        AttackerA_OHDI, AttackerA_OHOnHitDR, AttackerA_OHOnHitProbability, AttackerA_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# AttackerB
AttackerB_Label = "AttackerB"
AttackerB_HasBlindFight = False
AttackerB_IsRangedAttack = False
AttackerB_DevastatingCriticalDC = 51
AttackerB_SneakDice = 0
AttackerB_MHAB = [63, 58, 53, 48, 63]
AttackerB_OHAB = []
AttackerB_MHThreatRange = 12
AttackerB_OHThreatRange = 20
AttackerB_MHDI = [0, 0]
AttackerB_OHDI = []
AttackerB_MHOnHitDI = []
AttackerB_OHOnHitDI = []
AttackerB_MHDR = [0, 0]
AttackerB_OHDR = []
AttackerB_MHOnHitDR = []
AttackerB_OHOnHitDR = []
AttackerB_MHOnHitProbability = []
AttackerB_OHOnHitProbability = []
def AttackerB_MHNormalDamageRoll(): return [nDx(1, 6) + 30 + 10, nDx(2, 6)]
def AttackerB_MHCritalDamageRoll(): return [nDx(2, 6) + 60 + 20 + nDx(2, 6), nDx(4, 6)]
def AttackerB_OHNormalDamageRoll(): return []
def AttackerB_OHCritalDamageRoll(): return []
def AttackerB_MHOnHitDamageRoll(): return []
def AttackerB_OHOnHitDamageRoll(): return []
def AttackerB_ARTD():
    GetARTD(
        AttackerB_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        AttackerB_HasBlindFight, AttackerB_IsRangedAttack, AttackerB_DevastatingCriticalDC, AttackerB_SneakDice,
        AttackerB_MHAB, AttackerB_OHAB, AttackerB_MHThreatRange, AttackerB_OHThreatRange,
        AttackerB_MHDI, AttackerB_MHDR, AttackerB_MHNormalDamageRoll, AttackerB_MHCritalDamageRoll,
        AttackerB_OHDI, AttackerB_OHDR, AttackerB_OHNormalDamageRoll, AttackerB_OHCritalDamageRoll,
        AttackerB_MHOnHitDI, AttackerB_MHOnHitDR, AttackerB_MHOnHitProbability, AttackerB_MHOnHitDamageRoll,
        AttackerB_OHDI, AttackerB_OHOnHitDR, AttackerB_OHOnHitProbability, AttackerB_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att2A
Att2A_Label = "Att2A"
Att2A_HasBlindFight = False
Att2A_IsRangedAttack = False
Att2A_DevastatingCriticalDC = 43
Att2A_SneakDice = 0
Att2A_MHAB = [53, 48, 43, 38, 53]
Att2A_OHAB = []
Att2A_MHThreatRange = 12
Att2A_OHThreatRange = 20
Att2A_MHDI = [0, 0]
Att2A_OHDI = []
Att2A_MHOnHitDI = []
Att2A_OHOnHitDI = []
Att2A_MHDR = [0, 0]
Att2A_OHDR = []
Att2A_MHOnHitDR = []
Att2A_OHOnHitDR = []
Att2A_MHOnHitProbability = []
Att2A_OHOnHitProbability = []
def Att2A_MHNormalDamageRoll(): return [nDx(1, 6) + 24 + 10, nDx(2, 6)]
def Att2A_MHCritalDamageRoll(): return [nDx(2, 6) + 48 + 20 + nDx(2, 6), nDx(4, 6)]
def Att2A_OHNormalDamageRoll(): return []
def Att2A_OHCritalDamageRoll(): return []
def Att2A_MHOnHitDamageRoll(): return []
def Att2A_OHOnHitDamageRoll(): return []
def Att2A_ARTD():
    GetARTD(
        Att2A_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att2A_HasBlindFight, Att2A_IsRangedAttack, Att2A_DevastatingCriticalDC, Att2A_SneakDice,
        Att2A_MHAB, Att2A_OHAB, Att2A_MHThreatRange, Att2A_OHThreatRange,
        Att2A_MHDI, Att2A_MHDR, Att2A_MHNormalDamageRoll, Att2A_MHCritalDamageRoll,
        Att2A_OHDI, Att2A_OHDR, Att2A_OHNormalDamageRoll, Att2A_OHCritalDamageRoll,
        Att2A_MHOnHitDI, Att2A_MHOnHitDR, Att2A_MHOnHitProbability, Att2A_MHOnHitDamageRoll,
        Att2A_OHDI, Att2A_OHOnHitDR, Att2A_OHOnHitProbability, Att2A_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att2B
Att2B_Label = "Att2B"
Att2B_HasBlindFight = False
Att2B_IsRangedAttack = False
Att2B_DevastatingCriticalDC = 43
Att2B_SneakDice = 0
Att2B_MHAB = [54, 49, 44, 39, 54]
Att2B_OHAB = []
Att2B_MHThreatRange = 12
Att2B_OHThreatRange = 20
Att2B_MHDI = [0, 0]
Att2B_OHDI = []
Att2B_MHOnHitDI = []
Att2B_OHOnHitDI = []
Att2B_MHDR = [0, 0]
Att2B_OHDR = []
Att2B_MHOnHitDR = []
Att2B_OHOnHitDR = []
Att2B_MHOnHitProbability = []
Att2B_OHOnHitProbability = []
def Att2B_MHNormalDamageRoll(): return [nDx(1, 6) + 20 + 10, nDx(2, 6)]
def Att2B_MHCritalDamageRoll(): return [nDx(2, 6) + 40 + 20 + nDx(2, 6), nDx(4, 6)]
def Att2B_OHNormalDamageRoll(): return []
def Att2B_OHCritalDamageRoll(): return []
def Att2B_MHOnHitDamageRoll(): return []
def Att2B_OHOnHitDamageRoll(): return []
def Att2B_ARTD():
    GetARTD(
        Att2B_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att2B_HasBlindFight, Att2B_IsRangedAttack, Att2B_DevastatingCriticalDC, Att2B_SneakDice,
        Att2B_MHAB, Att2B_OHAB, Att2B_MHThreatRange, Att2B_OHThreatRange,
        Att2B_MHDI, Att2B_MHDR, Att2B_MHNormalDamageRoll, Att2B_MHCritalDamageRoll,
        Att2B_OHDI, Att2B_OHDR, Att2B_OHNormalDamageRoll, Att2B_OHCritalDamageRoll,
        Att2B_MHOnHitDI, Att2B_MHOnHitDR, Att2B_MHOnHitProbability, Att2B_MHOnHitDamageRoll,
        Att2B_OHDI, Att2B_OHOnHitDR, Att2B_OHOnHitProbability, Att2B_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att2C
Att2C_Label = "Att2C"
Att2C_HasBlindFight = False
Att2C_IsRangedAttack = False
Att2C_DevastatingCriticalDC = 43
Att2C_SneakDice = 0
Att2C_MHAB = [53, 48, 43, 38, 53]
Att2C_OHAB = []
Att2C_MHThreatRange = 12
Att2C_OHThreatRange = 20
Att2C_MHDI = [0, 0]
Att2C_OHDI = []
Att2C_MHOnHitDI = []
Att2C_OHOnHitDI = []
Att2C_MHDR = [0, 0]
Att2C_OHDR = []
Att2C_MHOnHitDR = []
Att2C_OHOnHitDR = []
Att2C_MHOnHitProbability = []
Att2C_OHOnHitProbability = []
def Att2C_MHNormalDamageRoll(): return [nDx(1, 6) + 20 + 10, nDx(2, 6)]
def Att2C_MHCritalDamageRoll(): return [nDx(2, 6) + 40 + 20 + nDx(2, 6), nDx(4, 6)]
def Att2C_OHNormalDamageRoll(): return []
def Att2C_OHCritalDamageRoll(): return []
def Att2C_MHOnHitDamageRoll(): return []
def Att2C_OHOnHitDamageRoll(): return []
def Att2C_ARTD():
    GetARTD(
        Att2C_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att2C_HasBlindFight, Att2C_IsRangedAttack, Att2C_DevastatingCriticalDC, Att2C_SneakDice,
        Att2C_MHAB, Att2C_OHAB, Att2C_MHThreatRange, Att2C_OHThreatRange,
        Att2C_MHDI, Att2C_MHDR, Att2C_MHNormalDamageRoll, Att2C_MHCritalDamageRoll,
        Att2C_OHDI, Att2C_OHDR, Att2C_OHNormalDamageRoll, Att2C_OHCritalDamageRoll,
        Att2C_MHOnHitDI, Att2C_MHOnHitDR, Att2C_MHOnHitProbability, Att2C_MHOnHitDamageRoll,
        Att2C_OHDI, Att2C_OHOnHitDR, Att2C_OHOnHitProbability, Att2C_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att3A
Att3A_Label = "Att3A"
Att3A_HasBlindFight = False
Att3A_IsRangedAttack = False
Att3A_DevastatingCriticalDC = 41
Att3A_SneakDice = 0
Att3A_MHAB = [51, 46, 41, 36, 51]
Att3A_OHAB = []
Att3A_MHThreatRange = 12
Att3A_OHThreatRange = 20
Att3A_MHDI = [0, 0]
Att3A_OHDI = []
Att3A_MHOnHitDI = []
Att3A_OHOnHitDI = []
Att3A_MHDR = [0, 0]
Att3A_OHDR = []
Att3A_MHOnHitDR = []
Att3A_OHOnHitDR = []
Att3A_MHOnHitProbability = []
Att3A_OHOnHitProbability = []
def Att3A_MHNormalDamageRoll(): return [nDx(1, 6) + 19 + 10, nDx(2, 6)]
def Att3A_MHCritalDamageRoll(): return [nDx(2, 6) + 38 + 20 + nDx(2, 6), nDx(4, 6)]
def Att3A_OHNormalDamageRoll(): return []
def Att3A_OHCritalDamageRoll(): return []
def Att3A_MHOnHitDamageRoll(): return []
def Att3A_OHOnHitDamageRoll(): return []
def Att3A_ARTD():
    GetARTD(
        Att3A_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att3A_HasBlindFight, Att3A_IsRangedAttack, Att3A_DevastatingCriticalDC, Att3A_SneakDice,
        Att3A_MHAB, Att3A_OHAB, Att3A_MHThreatRange, Att3A_OHThreatRange,
        Att3A_MHDI, Att3A_MHDR, Att3A_MHNormalDamageRoll, Att3A_MHCritalDamageRoll,
        Att3A_OHDI, Att3A_OHDR, Att3A_OHNormalDamageRoll, Att3A_OHCritalDamageRoll,
        Att3A_MHOnHitDI, Att3A_MHOnHitDR, Att3A_MHOnHitProbability, Att3A_MHOnHitDamageRoll,
        Att3A_OHDI, Att3A_OHOnHitDR, Att3A_OHOnHitProbability, Att3A_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att3B
Att3B_Label = "Att3B"
Att3B_HasBlindFight = False
Att3B_IsRangedAttack = False
Att3B_DevastatingCriticalDC = 41
Att3B_SneakDice = 0
Att3B_MHAB = [49, 44, 39, 34, 49]
Att3B_OHAB = []
Att3B_MHThreatRange = 12
Att3B_OHThreatRange = 20
Att3B_MHDI = [0, 0]
Att3B_OHDI = []
Att3B_MHOnHitDI = []
Att3B_OHOnHitDI = []
Att3B_MHDR = [0, 0]
Att3B_OHDR = []
Att3B_MHOnHitDR = []
Att3B_OHOnHitDR = []
Att3B_MHOnHitProbability = []
Att3B_OHOnHitProbability = []
def Att3B_MHNormalDamageRoll(): return [nDx(1, 6) + 19 + 10, nDx(2, 6)]
def Att3B_MHCritalDamageRoll(): return [nDx(2, 6) + 38 + 20 + nDx(2, 6), nDx(4, 6)]
def Att3B_OHNormalDamageRoll(): return []
def Att3B_OHCritalDamageRoll(): return []
def Att3B_MHOnHitDamageRoll(): return []
def Att3B_OHOnHitDamageRoll(): return []
def Att3B_ARTD():
    GetARTD(
        Att3B_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att3B_HasBlindFight, Att3B_IsRangedAttack, Att3B_DevastatingCriticalDC, Att3B_SneakDice,
        Att3B_MHAB, Att3B_OHAB, Att3B_MHThreatRange, Att3B_OHThreatRange,
        Att3B_MHDI, Att3B_MHDR, Att3B_MHNormalDamageRoll, Att3B_MHCritalDamageRoll,
        Att3B_OHDI, Att3B_OHDR, Att3B_OHNormalDamageRoll, Att3B_OHCritalDamageRoll,
        Att3B_MHOnHitDI, Att3B_MHOnHitDR, Att3B_MHOnHitProbability, Att3B_MHOnHitDamageRoll,
        Att3B_OHDI, Att3B_OHOnHitDR, Att3B_OHOnHitProbability, Att3B_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att4A
Att4A_Label = "Att4A"
Att4A_HasBlindFight = False
Att4A_IsRangedAttack = False
Att4A_DevastatingCriticalDC = 46
Att4A_SneakDice = 0
Att4A_MHAB = [56, 51, 46, 41, 56]
Att4A_OHAB = []
Att4A_MHThreatRange = 12
Att4A_OHThreatRange = 20
Att4A_MHDI = [0, 0]
Att4A_OHDI = []
Att4A_MHOnHitDI = []
Att4A_OHOnHitDI = []
Att4A_MHDR = [0, 0]
Att4A_OHDR = []
Att4A_MHOnHitDR = []
Att4A_OHOnHitDR = []
Att4A_MHOnHitProbability = []
Att4A_OHOnHitProbability = []
def Att4A_MHNormalDamageRoll(): return [nDx(1, 6) + 25 + 10, nDx(2, 6)]
def Att4A_MHCritalDamageRoll(): return [nDx(2, 6) + 50 + 20 + nDx(2, 6), nDx(4, 6)]
def Att4A_OHNormalDamageRoll(): return []
def Att4A_OHCritalDamageRoll(): return []
def Att4A_MHOnHitDamageRoll(): return []
def Att4A_OHOnHitDamageRoll(): return []
def Att4A_ARTD():
    GetARTD(
        Att4A_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att4A_HasBlindFight, Att4A_IsRangedAttack, Att4A_DevastatingCriticalDC, Att4A_SneakDice,
        Att4A_MHAB, Att4A_OHAB, Att4A_MHThreatRange, Att4A_OHThreatRange,
        Att4A_MHDI, Att4A_MHDR, Att4A_MHNormalDamageRoll, Att4A_MHCritalDamageRoll,
        Att4A_OHDI, Att4A_OHDR, Att4A_OHNormalDamageRoll, Att4A_OHCritalDamageRoll,
        Att4A_MHOnHitDI, Att4A_MHOnHitDR, Att4A_MHOnHitProbability, Att4A_MHOnHitDamageRoll,
        Att4A_OHDI, Att4A_OHOnHitDR, Att4A_OHOnHitProbability, Att4A_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
# Att4B
Att4B_Label = "Att4B"
Att4B_HasBlindFight = False
Att4B_IsRangedAttack = False
Att4B_DevastatingCriticalDC = 46
Att4B_SneakDice = 0
Att4B_MHAB = [57, 52, 47, 42, 57]
Att4B_OHAB = []
Att4B_MHThreatRange = 12
Att4B_OHThreatRange = 20
Att4B_MHDI = [0, 0]
Att4B_OHDI = []
Att4B_MHOnHitDI = []
Att4B_OHOnHitDI = []
Att4B_MHDR = [0, 0]
Att4B_OHDR = []
Att4B_MHOnHitDR = []
Att4B_OHOnHitDR = []
Att4B_MHOnHitProbability = []
Att4B_OHOnHitProbability = []
def Att4B_MHNormalDamageRoll(): return [nDx(1, 6) + 21 + 10, nDx(2, 6)]
def Att4B_MHCritalDamageRoll(): return [nDx(2, 6) + 42 + 20 + nDx(2, 6), nDx(4, 6)]
def Att4B_OHNormalDamageRoll(): return []
def Att4B_OHCritalDamageRoll(): return []
def Att4B_MHOnHitDamageRoll(): return []
def Att4B_OHOnHitDamageRoll(): return []
def Att4B_ARTD():
    GetARTD(
        Att4B_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        Att4B_HasBlindFight, Att4B_IsRangedAttack, Att4B_DevastatingCriticalDC, Att4B_SneakDice,
        Att4B_MHAB, Att4B_OHAB, Att4B_MHThreatRange, Att4B_OHThreatRange,
        Att4B_MHDI, Att4B_MHDR, Att4B_MHNormalDamageRoll, Att4B_MHCritalDamageRoll,
        Att4B_OHDI, Att4B_OHDR, Att4B_OHNormalDamageRoll, Att4B_OHCritalDamageRoll,
        Att4B_MHOnHitDI, Att4B_MHOnHitDR, Att4B_MHOnHitProbability, Att4B_MHOnHitDamageRoll,
        Att4B_OHDI, Att4B_OHOnHitDR, Att4B_OHOnHitProbability, Att4B_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
def Total_Results_1():
    AttackerA_ARTD()
    AttackerB_ARTD()
def Total_Results_2():
    Att2A_ARTD()
    Att2B_ARTD()
    Att2C_ARTD()
def Total_Results_3():
    Att3A_ARTD()
    Att3B_ARTD()
def Total_Results_4():
    Att4A_ARTD()
    Att4B_ARTD()
##########
