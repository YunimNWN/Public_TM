##########
import pathlib
import sys
sys.path.append(str(pathlib.Path(__file__).parent.absolute()))
from __BaseDCCalc import *
##########
# Defender B
TemplateTarget_AC = 76
TemplateTarget_Concealment = 0
TemplateTarget_DeflectArrows = 0
TemplateTarget_Fortitude = 42
TemplateTarget_HasEpicDodge = False
TemplateTarget_HP = 460
TemplateTarget_IsCriticalImmune = False
TemplateTarget_IsSneakImmune = False
Rules_Is1AutoFail = True
# Attacker Template
TemplateAttacker_Label = "Attacker Template"
TemplateAttacker_HasBlindFight = False
TemplateAttacker_IsRangedAttack = False
TemplateAttacker_DevastatingCriticalDC = 0
TemplateAttacker_SneakDice = 0
TemplateAttacker_MHAB = []
TemplateAttacker_OHAB = []
TemplateAttacker_MHThreatRange = 20
TemplateAttacker_OHThreatRange = 20
TemplateAttacker_MHDI = []
TemplateAttacker_OHDI = []
TemplateAttacker_MHOnHitDI = []
TemplateAttacker_OHOnHitDI = []
TemplateAttacker_MHDR = []
TemplateAttacker_OHDR = []
TemplateAttacker_MHOnHitDR = []
TemplateAttacker_OHOnHitDR = []
TemplateAttacker_MHOnHitProbability = []
TemplateAttacker_OHOnHitProbability = []
def TemplateAttacker_MHNormalDamageRoll(): return []
def TemplateAttacker_MHCritalDamageRoll(): return []
def TemplateAttacker_OHNormalDamageRoll(): return []
def TemplateAttacker_OHCritalDamageRoll(): return []
def TemplateAttacker_MHOnHitDamageRoll(): return []
def TemplateAttacker_OHOnHitDamageRoll(): return []
def TemplateAttacker_ARTD():
    GetARTD(
        TemplateAttacker_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        TemplateAttacker_HasBlindFight, TemplateAttacker_IsRangedAttack, TemplateAttacker_DevastatingCriticalDC, TemplateAttacker_SneakDice,
        TemplateAttacker_MHAB, TemplateAttacker_OHAB, TemplateAttacker_MHThreatRange, TemplateAttacker_OHThreatRange,
        TemplateAttacker_MHDI, TemplateAttacker_MHDR, TemplateAttacker_MHNormalDamageRoll, TemplateAttacker_MHCritalDamageRoll,
        TemplateAttacker_OHDI, TemplateAttacker_OHDR, TemplateAttacker_OHNormalDamageRoll, TemplateAttacker_OHCritalDamageRoll,
        TemplateAttacker_MHOnHitDI, TemplateAttacker_MHOnHitDR, TemplateAttacker_MHOnHitProbability, TemplateAttacker_MHOnHitDamageRoll,
        TemplateAttacker_OHDI, TemplateAttacker_OHOnHitDR, TemplateAttacker_OHOnHitProbability, TemplateAttacker_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
