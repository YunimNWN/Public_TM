##########
import math
import random
##########
Constant_ADPHSampleNumber = 10000
##########
def nDx(DiceNumber, DiceSides):
    Result = 0
    if DiceNumber > 0 and DiceSides > 0:
        for a in range(DiceNumber):
            Result += random.randint(1, DiceSides)
    return Result
def GetDIDamage(Damage, DI):
    DI_Bounded = DI
    if DI_Bounded > 1:
        DI_Bounded = 1
    if DI_Bounded < -1:
        DI_Bounded = -1
    if DI_Bounded == 0:
        Result = max(Damage, 0)
    elif DI_Bounded > 0:
        DamageDecrease = int(math.floor(Damage * DI_Bounded))
        Result = max(min(Damage - DamageDecrease, Damage - 1), 0)
    elif DI_Bounded < 0:
        DamageIncrease = int(math.floor(Damage * abs(DI_Bounded)))
        Result = max(Damage + DamageIncrease, 0)
    return Result
def GetDRDamage(Damage, DR):
    DR_Bounded = DR
    if DR_Bounded < 0:
        DR_Bounded = 0
    Result = max(Damage - DR_Bounded, 0)
    return Result
def GetDIDRDamage(Damage, DI, DR):
    DIDamage = GetDIDamage(Damage, DI)
    Result = GetDRDamage(DIDamage, DR)
    return Result
def GetDIDRDamageMultiple(Damage_List, DI_List, DR_List):
    Result = 0
    ListLengthsEqual = len(Damage_List) == len(DI_List) == len(DR_List)
    if not ListLengthsEqual:
        print("GetDIDRDamageMultiple Error: Unequal list length.")
    DamageTypes = len(Damage_List)
    if ListLengthsEqual and DamageTypes > 0:
        DIDRDamage_List = []
        for a in range(DamageTypes):
            DIDRDamage = GetDIDRDamage(Damage_List[a], DI_List[a], DR_List[a])
            DIDRDamage_List.append(DIDRDamage)
        Result = sum(DIDRDamage_List)
    return Result
def GetADPH(
    SampleNumber,
    TargetIsCriticalImmune, TargetIsSneakImmune,
    SneakDice,
    MHDI_List, MHDR_List, MHNormalDamage_Function, MHCriticalDamage_Function,
    OHDI_List, OHDR_List, OHNormalDamage_Function, OHCriticalDamage_Function,
    MHOnHitDI_List, MHOnHitDR_List, MHOnHitProbability_List, MHOnHitDamage_Function,
    OHOnHitDI_List, OHOnHitDR_List, OHOnHitProbability_List, OHOnHitDamage_Function):
    MHNormalAverageDamage = 0
    MHCriticalAverageDamage = 0
    OHNormalAverageDamage = 0
    OHCriticalAverageDamage = 0
    MHOnHitAverageDamage = 0
    OHOnHitAverageDamage = 0
    AverageDamageRoundingDigits = 4
    MHListLengthsEqual = len(MHDI_List) == len(MHDR_List) == len(MHNormalDamage_Function()) == len(MHCriticalDamage_Function())
    if not MHListLengthsEqual:
        print("GetADPH Error: Unequal MH list length.")
    OHListLengthsEqual = len(OHDI_List) == len(OHDR_List) == len(OHNormalDamage_Function()) == len(OHCriticalDamage_Function())
    if not OHListLengthsEqual:
        print("GetADPH Error: Unequal OH list length.")
    MHOnHitListLengthsEqual = len(MHOnHitDI_List) == len(MHOnHitDR_List) == len(MHOnHitProbability_List) == len(MHOnHitDamage_Function())
    if not MHOnHitListLengthsEqual:
        print("GetADPH Error: Unequal MHOnHit list length.")
    OHOnHitListLengthsEqual = len(OHOnHitDI_List) == len(OHOnHitDR_List) == len(OHOnHitProbability_List) == len(OHOnHitDamage_Function())
    if not OHOnHitListLengthsEqual:
        print("GetADPH Error: Unequal OHOnHit list length.")
    MHDamageTypes = len(MHNormalDamage_Function())
    OHDamageTypes = len(OHNormalDamage_Function())
    MHOnHitEffectTypes = len(MHOnHitDamage_Function())
    OHOnHitEffectTypes = len(OHOnHitDamage_Function())
    if MHListLengthsEqual and MHDamageTypes > 0:
        MHNormalDamageValues_List = []
        for a in range(SampleNumber):
            MHNormalDamageSample_List = MHNormalDamage_Function()
            if not TargetIsSneakImmune and SneakDice > 0:
                MHNormalDamageSample_List[0] += nDx(SneakDice, 6)
            if MHNormalDamageSample_List[0] < 1:
                MHNormalDamageSample_List[0] = 1
            MHDIDRNormalDamageValue = GetDIDRDamageMultiple(MHNormalDamageSample_List, MHDI_List, MHDR_List)
            MHNormalDamageValues_List.append(MHDIDRNormalDamageValue)
        MHNormalAverageDamage = round(sum(MHNormalDamageValues_List) / SampleNumber, AverageDamageRoundingDigits)
        if TargetIsCriticalImmune:
            MHCriticalAverageDamage = MHNormalAverageDamage
        elif not TargetIsCriticalImmune:
            MHCriticalDamageValues_List = []
            for b in range(SampleNumber):
                MHCriticalDamageSample_List = MHCriticalDamage_Function()
                if not TargetIsSneakImmune and SneakDice > 0:
                    MHCriticalDamageSample_List[0] += nDx(SneakDice, 6)
                if MHCriticalDamageSample_List[0] < 1:
                    MHCriticalDamageSample_List[0] = 1
                MHDIDRCriticalDamageValue = GetDIDRDamageMultiple(MHCriticalDamageSample_List, MHDI_List, MHDR_List)
                MHCriticalDamageValues_List.append(MHDIDRCriticalDamageValue)
            MHCriticalAverageDamage = round(sum(MHCriticalDamageValues_List) / SampleNumber, AverageDamageRoundingDigits)
    if OHListLengthsEqual and OHDamageTypes > 0:
        OHNormalDamageValues_List = []
        for c in range(SampleNumber):
            OHNormalDamageSample_List = OHNormalDamage_Function()
            if not TargetIsSneakImmune and SneakDice > 0:
                OHNormalDamageSample_List[0] += nDx(SneakDice, 6)
            if OHNormalDamageSample_List[0] < 1:
                OHNormalDamageSample_List[0] = 1
            OHDIDRNormalDamageValue = GetDIDRDamageMultiple(OHNormalDamageSample_List, OHDI_List, OHDR_List)
            OHNormalDamageValues_List.append(OHDIDRNormalDamageValue)
        OHNormalAverageDamage = round(sum(OHNormalDamageValues_List) / SampleNumber, AverageDamageRoundingDigits)
        if TargetIsCriticalImmune:
            OHCriticalAverageDamage = OHNormalAverageDamage
        elif not TargetIsCriticalImmune:
            OHCriticalDamageValues_List = []
            for d in range(SampleNumber):
                OHCriticalDamageSample_List = OHCriticalDamage_Function()
                if not TargetIsSneakImmune and SneakDice > 0:
                    OHCriticalDamageSample_List[0] += nDx(SneakDice, 6)
                if OHCriticalDamageSample_List[0] < 1:
                    OHCriticalDamageSample_List[0] = 1
                OHDIDRCriticalDamageValue = GetDIDRDamageMultiple(OHCriticalDamageSample_List, OHDI_List, OHDR_List)
                OHCriticalDamageValues_List.append(OHDIDRCriticalDamageValue)
            OHCriticalAverageDamage = round(sum(OHCriticalDamageValues_List) / SampleNumber, AverageDamageRoundingDigits)
    if MHOnHitListLengthsEqual and MHOnHitEffectTypes > 0:
        MHOnHitDamageTotal_List = []
        for e in range(MHOnHitEffectTypes):
            MHOnHitDamageTotal_List.append(0)
        for f in range(SampleNumber):
            MHOnHitDamageSample_List = MHOnHitDamage_Function()
            for g in range(MHOnHitEffectTypes):
                MHDIDROnHitDamageValue = GetDIDRDamage(MHOnHitDamageSample_List[g], MHOnHitDI_List[g], MHOnHitDR_List[g])
                MHOnHitDamageTotal_List[g] += MHDIDROnHitDamageValue
        MHOnHitAverageDamage = 0
        for h in range(MHOnHitEffectTypes):
            MHOnHitAverageDamage = round(MHOnHitAverageDamage + ((MHOnHitDamageTotal_List[h] * MHOnHitProbability_List[h])/ SampleNumber), AverageDamageRoundingDigits + 2)
        MHOnHitAverageDamage = round(MHOnHitAverageDamage, AverageDamageRoundingDigits)
    if OHOnHitListLengthsEqual and OHOnHitEffectTypes > 0:
        OHOnHitDamageTotal_List = []
        for i in range(OHOnHitEffectTypes):
            OHOnHitDamageTotal_List.append(0)
        for j in range(SampleNumber):
            OHOnHitDamageSample_List = OHOnHitDamage_Function()
            for k in range(OHOnHitEffectTypes):
                OHDIDROnHitDamageValue = GetDIDRDamage(OHOnHitDamageSample_List[k], OHOnHitDI_List[k], OHOnHitDR_List[k])
                OHOnHitDamageTotal_List[k] += OHDIDROnHitDamageValue
        OHOnHitAverageDamage = 0
        for l in range(OHOnHitEffectTypes):
            OHOnHitAverageDamage = round(OHOnHitAverageDamage + ((OHOnHitDamageTotal_List[l] * OHOnHitProbability_List[l])/ SampleNumber), AverageDamageRoundingDigits + 2)
        OHOnHitAverageDamage = round(OHOnHitAverageDamage, AverageDamageRoundingDigits)
    Result = [MHNormalAverageDamage, MHCriticalAverageDamage, OHNormalAverageDamage, OHCriticalAverageDamage, MHOnHitAverageDamage, OHOnHitAverageDamage]
    return Result
def GetMissProbability(AB, TargetAC):
    AttackRollRequired = TargetAC - AB
    if AttackRollRequired > 20:
        AttackRollRequired = 20
    if AttackRollRequired < 2:
        AttackRollRequired = 2
    Result = round((AttackRollRequired - 1) / 20, 2)
    return Result
def GetCriticalHitThreatenedConditionalProbability(AB, TargetAC, ThreatRange):
    ThreatRange_Bounded = ThreatRange
    if ThreatRange_Bounded > 20:
        ThreatRange_Bounded = 20
    if ThreatRange_Bounded < 2:
        ThreatRange_Bounded = 2
    ProbabilityRoundingDigits = 16
    AttackRollRequired = TargetAC - AB
    if AttackRollRequired > 20:
        AttackRollRequired = 20
    if AttackRollRequired < 2:
        AttackRollRequired = 2
    if AttackRollRequired >= ThreatRange_Bounded:
        Result = 1
    else:
        Result = round((21 - ThreatRange_Bounded) / (21 - AttackRollRequired), ProbabilityRoundingDigits)
    return Result
def GetCriticalHitConfirmedProbability(AB, TargetAC):
    ThreatRollRequired = TargetAC - AB
    if ThreatRollRequired > 20:
        Result = 0
    elif ThreatRollRequired <= 1:
        Result = 1
    else:
        Result = round((21 - ThreatRollRequired) / 20, 2)
    return Result
def GetConcealmentHitProbability(HasBlindFight, TargetConcealment):
    TargetConcealment_Bounded = TargetConcealment
    if TargetConcealment_Bounded > 1:
        TargetConcealment_Bounded = 1
    if TargetConcealment_Bounded < 0:
        TargetConcealment_Bounded = 0
    if TargetConcealment_Bounded == 0:
        Result = 1
    if not HasBlindFight and TargetConcealment_Bounded > 0:
        Result = round(1 - TargetConcealment_Bounded, 2)
    if HasBlindFight and TargetConcealment_Bounded > 0:
        Result = round(1 - (TargetConcealment_Bounded ** 2), 4)
    return Result
def GetSpecialHitProbability(AB_List, TargetAC, TargetDeflectArrows, TargetHasEpicDodge, IsRangedAttack):
    Result = []
    TargetDeflectArrows_Bounded = TargetDeflectArrows
    if TargetDeflectArrows_Bounded > 1:
        TargetDeflectArrows_Bounded = 1
    if TargetDeflectArrows_Bounded < 0:
        TargetDeflectArrows_Bounded = 0
    APR = len(AB_List)
    if APR > 0:
        MissProbability_List = []
        for a in range(APR):
            MissProbability = GetMissProbability(AB_List[a], TargetAC)
            MissProbability_List.append(MissProbability)
        if not TargetHasEpicDodge and (not IsRangedAttack or TargetDeflectArrows_Bounded == 0):
            for b in range(APR):
                HitProbability = round(1 - MissProbability_List[b], 2)
                Result.append(HitProbability)
        elif TargetHasEpicDodge ^ (IsRangedAttack and TargetDeflectArrows_Bounded > 0):
            if TargetHasEpicDodge:
                BlockProbability = 1
            elif not TargetHasEpicDodge:
                BlockProbability = TargetDeflectArrows_Bounded
            for c in range(APR):
                HitProbability = round(1 - MissProbability_List[c], 2)
                TriggerProbability = HitProbability
                for d in range(c):
                    TriggerProbability = round(TriggerProbability * MissProbability_List[d], 4 + (d * 2))
                SpecialHitProbability = round(HitProbability - (BlockProbability * TriggerProbability), 6 + (c * 2))
                Result.append(SpecialHitProbability)
        elif TargetHasEpicDodge and IsRangedAttack and TargetDeflectArrows_Bounded > 0:
            Result = [0]
            if APR > 1:
                for e in range(1, APR):
                    HitProbability = round(1 - MissProbability_List[e], 2)
                    EDTriggerProbability = HitProbability
                    DATriggerProbability_List = []
                    for f in range(e):
                        EDTriggerProbability = round(EDTriggerProbability * MissProbability_List[f], 4 + (f * 2))
                        DATriggerProbability = round(HitProbability * round(1 - MissProbability_List[f], 2), 4)
                        for g in range(e):
                            if g != f:
                                DATriggerProbability = round(DATriggerProbability * MissProbability_List[g], 6 + (g * 2))
                        DATriggerProbability_List.append(DATriggerProbability)
                    SpecialHitProbability = round(HitProbability - EDTriggerProbability - round(TargetDeflectArrows_Bounded * sum(DATriggerProbability_List), 8 + (e * 2)), 8 + (e * 2))
                    Result.append(SpecialHitProbability)
    return Result
def GetAHPR(
    TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge,
    HasBlindFight, IsRangedAttack,
    MHAB_List, OHAB_List, MHThreatRange, OHThreatRange):
    MHNormalAverageHits = 0
    MHCriticalAverageHits = 0
    OHNormalAverageHits = 0
    OHCriticalAverageHits = 0
    AverageHitsRoundingDigits = 4
    MHAPR = len(MHAB_List)
    OHAPR = len(OHAB_List)
    ConcealmentHitProbability = GetConcealmentHitProbability(HasBlindFight, TargetConcealment)
    if MHAPR > 0 or OHAPR > 0:
        TotalAB_List = MHAB_List + OHAB_List
        TotalAPR = len(TotalAB_List)
        TotalSpecialHitProbability_List = GetSpecialHitProbability(TotalAB_List, TargetAC, TargetDeflectArrows, TargetHasEpicDodge, IsRangedAttack)
        if MHAPR > 0:
            MHNormalHitProbability_List = []
            MHCriticalHitProbability_List = []
            for a in range(MHAPR):
                MHNormalHitProbability_List.append(TotalSpecialHitProbability_List[a])
                MHCriticalHitProbability_List.append(TotalSpecialHitProbability_List[a])
            for b in range(MHAPR):
                CriticalHitThreatenedProbability = GetCriticalHitThreatenedConditionalProbability(MHAB_List[b], TargetAC, MHThreatRange)
                CriticalHitConfirmedProbability = GetCriticalHitConfirmedProbability(MHAB_List[b], TargetAC)
                MHNormalHitProbability_List[b] = MHNormalHitProbability_List[b] * ConcealmentHitProbability * (1 - (CriticalHitThreatenedProbability * CriticalHitConfirmedProbability))
                MHCriticalHitProbability_List[b] = MHCriticalHitProbability_List[b] * ConcealmentHitProbability * CriticalHitThreatenedProbability * CriticalHitConfirmedProbability
            MHNormalAverageHits = round(sum(MHNormalHitProbability_List), AverageHitsRoundingDigits)
            MHCriticalAverageHits = round(sum(MHCriticalHitProbability_List), AverageHitsRoundingDigits)
        if OHAPR > 0:
            OHNormalHitProbability_List = []
            OHCriticalHitProbability_List = []
            for c in range(MHAPR, TotalAPR):
                OHNormalHitProbability_List.append(TotalSpecialHitProbability_List[c])
                OHCriticalHitProbability_List.append(TotalSpecialHitProbability_List[c])
            for d in range(OHAPR):
                CriticalHitThreatenedProbability = GetCriticalHitThreatenedConditionalProbability(OHAB_List[d], TargetAC, OHThreatRange)
                CriticalHitConfirmedProbability = GetCriticalHitConfirmedProbability(OHAB_List[d], TargetAC)
                OHNormalHitProbability_List[d] = OHNormalHitProbability_List[d] * ConcealmentHitProbability * (1 - (CriticalHitThreatenedProbability * CriticalHitConfirmedProbability))
                OHCriticalHitProbability_List[d] = OHCriticalHitProbability_List[d] * ConcealmentHitProbability * CriticalHitThreatenedProbability * CriticalHitConfirmedProbability
            OHNormalAverageHits = round(sum(OHNormalHitProbability_List), AverageHitsRoundingDigits)
            OHCriticalAverageHits = round(sum(OHCriticalHitProbability_List), AverageHitsRoundingDigits)
    Result = [MHNormalAverageHits, MHCriticalAverageHits, OHNormalAverageHits, OHCriticalAverageHits]
    return Result
def GetADPR(
    TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge, TargetIsCriticalImmune, TargetIsSneakImmune,
    HasBlindFight, IsRangedAttack, SneakDice,
    MHAB_List, OHAB_List, MHThreatRange, OHThreatRange,
    MHDI_List, MHDR_List, MHNormalDamage_Function, MHCriticalDamage_Function,
    OHDI_List, OHDR_List, OHNormalDamage_Function, OHCriticalDamage_Function,
    MHOnHitDI_List, MHOnHitDR_List, MHOnHitProbability_List, MHOnHitDamage_Function,
    OHOnHitDI_List, OHOnHitDR_List, OHOnHitProbability_List, OHOnHitDamage_Function):
    ADPH = GetADPH(
        Constant_ADPHSampleNumber,
        TargetIsCriticalImmune, TargetIsSneakImmune,
        SneakDice,
        MHDI_List, MHDR_List, MHNormalDamage_Function, MHCriticalDamage_Function,
        OHDI_List, OHDR_List, OHNormalDamage_Function, OHCriticalDamage_Function,
        MHOnHitDI_List, MHOnHitDR_List, MHOnHitProbability_List, MHOnHitDamage_Function,
        OHOnHitDI_List, OHOnHitDR_List, OHOnHitProbability_List, OHOnHitDamage_Function)
    AHPR = GetAHPR(
        TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge,
        HasBlindFight, IsRangedAttack,
        MHAB_List, OHAB_List, MHThreatRange, OHThreatRange)
    ADPRRoundingDigits = 2
    Result = round((ADPH[0] * AHPR[0]) + (ADPH[1] * AHPR[1]) + (ADPH[2] * AHPR[2]) + (ADPH[3] * AHPR[3]) + (ADPH[4] * (AHPR[0] + AHPR[1])) + (ADPH[5] * (AHPR[2] + AHPR[3])), ADPRRoundingDigits)
    return Result
def GetDevastatingCriticalSuccessfulProbability(TargetIsCriticalImmune, TargetFortitude, DevastatingCriticalDC, Is1AutoFail = True):
    Result = 0
    if not TargetIsCriticalImmune and DevastatingCriticalDC > 0:
        FortitudeRollRequired = DevastatingCriticalDC - TargetFortitude
        if FortitudeRollRequired > 20:
            FortitudeRollRequired = 20
        if FortitudeRollRequired < 1:
            FortitudeRollRequired = 1
        if Is1AutoFail:
            if FortitudeRollRequired == 1:
                Result = 0.05
            else:
                Result = round((FortitudeRollRequired - 1) / 20, 2)
        elif not Is1AutoFail:
            Result = round((FortitudeRollRequired - 1) / 20, 2)
    return Result
def GetACHPR(
    TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge,
    HasBlindFight, IsRangedAttack,
    MHAB_List, OHAB_List, MHThreatRange, OHThreatRange):
    Result = []
    ProbabilityRoundingDigits = 4
    MHAPR = len(MHAB_List)
    OHAPR = len(OHAB_List)
    ConcealmentHitProbability = GetConcealmentHitProbability(HasBlindFight, TargetConcealment)
    if MHAPR > 0 or OHAPR > 0:
        TotalAB_List = MHAB_List + OHAB_List
        TotalAPR = len(TotalAB_List)
        TotalSpecialHitProbability_List = GetSpecialHitProbability(TotalAB_List, TargetAC, TargetDeflectArrows, TargetHasEpicDodge, IsRangedAttack)
        if MHAPR > 0:
            MHNormalHitProbability_List = []
            MHCriticalHitProbability_List = []
            for a in range(MHAPR):
                MHNormalHitProbability_List.append(TotalSpecialHitProbability_List[a])
                MHCriticalHitProbability_List.append(TotalSpecialHitProbability_List[a])
            for b in range(MHAPR):
                CriticalHitThreatenedProbability = GetCriticalHitThreatenedConditionalProbability(MHAB_List[b], TargetAC, MHThreatRange)
                CriticalHitConfirmedProbability = GetCriticalHitConfirmedProbability(MHAB_List[b], TargetAC)
                MHNormalHitProbability_List[b] = MHNormalHitProbability_List[b] * ConcealmentHitProbability * (1 - (CriticalHitThreatenedProbability * CriticalHitConfirmedProbability))
                MHCriticalHitProbability_List[b] = MHCriticalHitProbability_List[b] * ConcealmentHitProbability * CriticalHitThreatenedProbability * CriticalHitConfirmedProbability
            for c in range(len(MHCriticalHitProbability_List)):
                Result.append(round(MHCriticalHitProbability_List[c], ProbabilityRoundingDigits))
        if OHAPR > 0:
            OHNormalHitProbability_List = []
            OHCriticalHitProbability_List = []
            for d in range(MHAPR, TotalAPR):
                OHNormalHitProbability_List.append(TotalSpecialHitProbability_List[d])
                OHCriticalHitProbability_List.append(TotalSpecialHitProbability_List[d])
            for e in range(OHAPR):
                CriticalHitThreatenedProbability = GetCriticalHitThreatenedConditionalProbability(OHAB_List[e], TargetAC, OHThreatRange)
                CriticalHitConfirmedProbability = GetCriticalHitConfirmedProbability(OHAB_List[e], TargetAC)
                OHNormalHitProbability_List[e] = OHNormalHitProbability_List[e] * ConcealmentHitProbability * (1 - (CriticalHitThreatenedProbability * CriticalHitConfirmedProbability))
                OHCriticalHitProbability_List[e] = OHCriticalHitProbability_List[e] * ConcealmentHitProbability * CriticalHitThreatenedProbability * CriticalHitConfirmedProbability
            for f in range(len(OHCriticalHitProbability_List)):
                Result.append(round(OHCriticalHitProbability_List[f], ProbabilityRoundingDigits))
    return Result
def GetADCHPPR(
    Label,
    TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge, TargetIsCriticalImmune, TargetFortitude,
    HasBlindFight, IsRangedAttack, DevastatingCriticalDC,
    MHAB_List, OHAB_List, MHThreatRange, OHThreatRange,
    Is1AutoFail = True):
    Result = 0
    ACHPR_List = GetACHPR(
        TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge,
        HasBlindFight, IsRangedAttack,
        MHAB_List, OHAB_List, MHThreatRange, OHThreatRange)
    print (Label, "ACHPR_List: " + str(ACHPR_List))
    DCSProbability = GetDevastatingCriticalSuccessfulProbability(TargetIsCriticalImmune, TargetFortitude, DevastatingCriticalDC, Is1AutoFail)
    print (Label, "DCSProbability: " + str(DCSProbability))
    APR = len(ACHPR_List)
    if (APR > 0):
        DCHProbability_List = []
        for a in range(APR):
            DCHProbability_List.append(round(ACHPR_List[a] * DCSProbability, 6))
        NDCHProb = 1
        for b in range(APR):
            NDCHProb *= round(1 - DCHProbability_List[b], 6)
        Result = round(1 - NDCHProb, 6)
    return Result
def GetARTD(
    Label,
    TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge, TargetFortitude, TargetHP, TargetIsCriticalImmune, TargetIsSneakImmune,
    HasBlindFight, IsRangedAttack, DevastatingCriticalDC, SneakDice,
    MHAB_List, OHAB_List, MHThreatRange, OHThreatRange,
    MHDI_List, MHDR_List, MHNormalDamage_Function, MHCriticalDamage_Function,
    OHDI_List, OHDR_List, OHNormalDamage_Function, OHCriticalDamage_Function,
    MHOnHitDI_List, MHOnHitDR_List, MHOnHitProbability_List, MHOnHitDamage_Function,
    OHOnHitDI_List, OHOnHitDR_List, OHOnHitProbability_List, OHOnHitDamage_Function,
    Is1AutoFail = True):
    Result = 0
    ADPR = GetADPR(
        TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge, TargetIsCriticalImmune, TargetIsSneakImmune,
        HasBlindFight, IsRangedAttack, SneakDice,
        MHAB_List, OHAB_List, MHThreatRange, OHThreatRange,
        MHDI_List, MHDR_List, MHNormalDamage_Function, MHCriticalDamage_Function,
        OHDI_List, OHDR_List, OHNormalDamage_Function, OHCriticalDamage_Function,
        MHOnHitDI_List, MHOnHitDR_List, MHOnHitProbability_List, MHOnHitDamage_Function,
        OHOnHitDI_List, OHOnHitDR_List, OHOnHitProbability_List, OHOnHitDamage_Function)
    print (Label, "ADPR: " + str(ADPR))
    if TargetHP > 0 and ADPR > 0:
        ARTDByDamage = math.ceil(TargetHP / ADPR)
        Result = ARTDByDamage
        ADCHPPR = GetADCHPPR(
            Label,
            TargetAC, TargetConcealment, TargetDeflectArrows, TargetHasEpicDodge, TargetIsCriticalImmune, TargetFortitude,
            HasBlindFight, IsRangedAttack, DevastatingCriticalDC,
            MHAB_List, OHAB_List, MHThreatRange, OHThreatRange,
            Is1AutoFail)
        print (Label, "ADCHPPR: " + str(ADCHPPR))
        if ADCHPPR > 0:
            ARTDRoundingDigits = 2
            Result = round((1 - ((1 - ADCHPPR)**ARTDByDamage))/ADCHPPR, ARTDRoundingDigits)
    print (Label, "ARTD: " + str(Result))
##########
# Target Template
TemplateTarget_AC = 0
TemplateTarget_Concealment = 0
TemplateTarget_DeflectArrows = 0
TemplateTarget_Fortitude = 0
TemplateTarget_HasEpicDodge = False
TemplateTarget_HP = 0
TemplateTarget_IsCriticalImmune = False
TemplateTarget_IsSneakImmune = False
Rules_Is1AutoFail = True
# Attacker Template
TemplateAttacker_Label = "Attacker Template"
TemplateAttacker_HasBlindFight = False
TemplateAttacker_IsRangedAttack = False
TemplateAttacker_DevastatingCriticalDC = 20
TemplateAttacker_SneakDice = 0
TemplateAttacker_MHAB = []
TemplateAttacker_OHAB = []
TemplateAttacker_MHThreatRange = 20
TemplateAttacker_OHThreatRange = 20
TemplateAttacker_MHDI = []
TemplateAttacker_OHDI = []
TemplateAttacker_MHOnHitDI = []
TemplateAttacker_OHOnHitDI = []
TemplateAttacker_MHDR = []
TemplateAttacker_OHDR = []
TemplateAttacker_MHOnHitDR = []
TemplateAttacker_OHOnHitDR = []
TemplateAttacker_MHOnHitProbability = []
TemplateAttacker_OHOnHitProbability = []
def TemplateAttacker_MHNormalDamageRoll(): return []
def TemplateAttacker_MHCritalDamageRoll(): return []
def TemplateAttacker_OHNormalDamageRoll(): return []
def TemplateAttacker_OHCritalDamageRoll(): return []
def TemplateAttacker_MHOnHitDamageRoll(): return []
def TemplateAttacker_OHOnHitDamageRoll(): return []
def TemplateAttacker_ARTD():
    GetARTD(
        TemplateAttacker_Label,
        TemplateTarget_AC, TemplateTarget_Concealment, TemplateTarget_DeflectArrows, TemplateTarget_HasEpicDodge, TemplateTarget_Fortitude, TemplateTarget_HP, TemplateTarget_IsCriticalImmune, TemplateTarget_IsSneakImmune,
        TemplateAttacker_HasBlindFight, TemplateAttacker_IsRangedAttack, TemplateAttacker_DevastatingCriticalDC, TemplateAttacker_SneakDice,
        TemplateAttacker_MHAB, TemplateAttacker_OHAB, TemplateAttacker_MHThreatRange, TemplateAttacker_OHThreatRange,
        TemplateAttacker_MHDI, TemplateAttacker_MHDR, TemplateAttacker_MHNormalDamageRoll, TemplateAttacker_MHCritalDamageRoll,
        TemplateAttacker_OHDI, TemplateAttacker_OHDR, TemplateAttacker_OHNormalDamageRoll, TemplateAttacker_OHCritalDamageRoll,
        TemplateAttacker_MHOnHitDI, TemplateAttacker_MHOnHitDR, TemplateAttacker_MHOnHitProbability, TemplateAttacker_MHOnHitDamageRoll,
        TemplateAttacker_OHDI, TemplateAttacker_OHOnHitDR, TemplateAttacker_OHOnHitProbability, TemplateAttacker_OHOnHitDamageRoll,
        Rules_Is1AutoFail)
##########
