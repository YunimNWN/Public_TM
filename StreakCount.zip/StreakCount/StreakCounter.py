##########
import random
##########
def StreakCount(Number_List):
    Result = []
    if len(Number_List) > 0:
        CurrentStreak_List = []
        StreakCount_List = []
        for a in range(len(Number_List)):
            if len(CurrentStreak_List) == 0:
                CurrentStreak_List.append(Number_List[a])
            elif len(CurrentStreak_List) > 0:
                if Number_List[a] == CurrentStreak_List[0]:
                    CurrentStreak_List.append(Number_List[a])
                else:
                    StreakCount_List.append(len(CurrentStreak_List))
                    CurrentStreak_List = [Number_List[a]]
            if a == (len(Number_List) - 1):
                StreakCount_List.append(len(CurrentStreak_List))
        MaxStreak = max(StreakCount_List)
        for b in range(MaxStreak):
            Result.append(0)
        for c in range(len(StreakCount_List)):
            Result[StreakCount_List[c] - 1] += 1
    #print("StreakCount Result: " + str(Result))
    return Result
def RandomRoll(NumberRolls, NumberSides):
    Result = []
    if NumberRolls > 0 and NumberSides > 1:
        for a in range(NumberRolls):
            Result.append(random.randint(1, NumberSides))
    #print("RandomRoll Result: " + str(Result))
    return Result
def TestRoll(NumberRolls, Attempts = 1):
    Result = []
    TotalStreakCount_List = []
    for a in range(Attempts):
        Streak_List = StreakCount(RandomRoll(NumberRolls, 20))
        for b in range(len(Streak_List)):
            while b >= len(TotalStreakCount_List):
                TotalStreakCount_List.append(0)
            TotalStreakCount_List[b] += Streak_List[b]
    for c in range(len(TotalStreakCount_List)):
        AverageCount = round(TotalStreakCount_List[c] / Attempts, 4)
        Result.append(AverageCount)
    #print("TestRoll TotalStreakCount_List: " + str(TotalStreakCount_List))
    #print("TestRoll Result: " + str(Result))
    return Result
##########
FileName1 = "CleanRolls1.txt"
FileName2 = "CleanRolls2.txt"
Data1_List = list(map(int, open(FileName1).read().split("\n")))
Data2_List = list(map(int, open(FileName2).read().split("\n")))
##########
#print(StreakCount(Data1_List))
#print(StreakCount(Data2_List))
##########
Number1 = 47358
Number2 = 29860
#print(TestRoll(Number1, 1000))
#print(TestRoll(Number2, 1000))
##########
